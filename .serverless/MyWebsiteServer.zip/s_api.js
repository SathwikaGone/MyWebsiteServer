
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'gonesathwika',
  applicationName: 'mywebsiteserverapp',
  appUid: 'NwX4WrXZ90gfgVQjTy',
  orgUid: 'ZS34mF3Dk73RPHdcdY',
  deploymentUid: '24bb95ad-9bdf-4881-a52c-b846a8e3a6c3',
  serviceName: 'MyWebsiteServer',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'devp',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'MyWebsiteServer-devp-api', timeout: 15 };

try {
  const userHandler = require('./lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}