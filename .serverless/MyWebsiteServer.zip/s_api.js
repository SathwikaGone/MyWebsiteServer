
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'gonesathwika',
  applicationName: 'mywebsiteserver-app',
  appUid: 'P536NBfFTRqjSSSmWL',
  orgUid: 'ZS34mF3Dk73RPHdcdY',
  deploymentUid: '154ed15f-846a-4f07-8b0f-6f75eaa7f105',
  serviceName: 'MyWebsiteServer',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'devv',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'MyWebsiteServer-devv-api', timeout: 15 };

try {
  const userHandler = require('./lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}