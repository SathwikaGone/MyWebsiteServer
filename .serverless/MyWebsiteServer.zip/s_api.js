
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'gonesathwika',
  applicationName: 'mywebsiteserver-app',
  appUid: 'P536NBfFTRqjSSSmWL',
  orgUid: 'ZS34mF3Dk73RPHdcdY',
  deploymentUid: '3a7087eb-e442-4f48-a405-7a23eb9b7ff2',
  serviceName: 'MyWebsiteServer',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'devv',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'MyWebsiteServer-devv-api', timeout: 15 };

try {
  const userHandler = require('./lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}