module.exports = {
  MongodbURI:
    "mongodb+srv://Sathwika:Sathwika@cluster0-y5jxg.mongodb.net/MyWebsite?retryWrites=true&w=majority"
};
